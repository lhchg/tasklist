int main(void)
{
    int a = -1;
    int b = a >> 1;
    return (a != b);
}
