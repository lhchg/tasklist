#!/bin/sh
# deletes all auto-generated / compiled files
git clean -dfX
